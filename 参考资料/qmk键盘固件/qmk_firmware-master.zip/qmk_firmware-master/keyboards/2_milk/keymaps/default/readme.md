# Default keymap for 2% Milk
![Picture](https://i.imgur.com/9PsZ6wa.png)
