# left and right mouse buttons
requested by WanderingVagrant
