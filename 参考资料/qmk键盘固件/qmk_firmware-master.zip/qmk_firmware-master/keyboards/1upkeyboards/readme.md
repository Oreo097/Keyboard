# 1UP Keyboards

1UP Keyboards is an online mechanical keyboard retailer located in New York, USA.

Website: [1UP Keyboards](https://www.1upkeyboards.com/)  
Discord: [Server Invite](https://discordapp.com/invite/c6SYn8)  
YouTube: [skiwithpete](https://www.youtube.com/user/skiwithpete)  