<div dir="rtl" markdown="1">
# מקורות ללמידה

המקורות הבאים מטרתם היא לתת למשתמשים חדשים בקהילת QMK כדי להבין לעומק את המידע שמגיע במסמכי המתחילים.

מקורות גיט:

* [מדריך כללי מעולה](https://www.codecademy.com/learn/learn-git)
* [משחק גיט כדי ללמוד מדוגמאות](https://learngitbranching.js.org/)
* [מקורות גיט כדי ללמוד עוד על GitHub](getting_started_github.md)
* [מקור גיט כדי ללמוד במפורש על QMK](contributing.md)

מקורות לפקודות שורה (Command Line):

* [מדריך טוב על Command Line](https://www.codecademy.com/learn/learn-the-command-line)
</div>