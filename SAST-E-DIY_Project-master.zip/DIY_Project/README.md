# 目前的项目情况：

1. Four Keys Keyboard：“生产力键盘”，探索人类本质必备！





### 更新记录

2020.2.19，上传Four Keys Keyboard的原理、PCB和固件