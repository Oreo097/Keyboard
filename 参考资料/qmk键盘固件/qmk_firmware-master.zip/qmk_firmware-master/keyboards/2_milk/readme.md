# 2% Milk

![2%Milk](https://i.imgur.com/Ud96uXn.png)

A 2% Meme board themed around a milk carton

Keyboard Maintainer: [Rionlion100](https://github.com/rionlion100)  
Hardware Availability: [Open Source](https://github.com/Rionlion100/Spaceboards/tree/master/Keyboards/2%25%20Milk)

Make example for this keyboard (after setting up your build environment):

    make 2_milk:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).

### Credits
+ Case design by Soft
+ PCB by PyroL
+ Name by jetpacktuxedo
