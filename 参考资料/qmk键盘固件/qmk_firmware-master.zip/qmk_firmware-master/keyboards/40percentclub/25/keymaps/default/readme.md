# The default split keymap for 25
