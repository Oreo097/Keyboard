# Dale's keymap for the Sweet16

I wanted to reuse a standard numpad keyset and have the full functionality of an larger numpad with a nod to Excel functionality.
