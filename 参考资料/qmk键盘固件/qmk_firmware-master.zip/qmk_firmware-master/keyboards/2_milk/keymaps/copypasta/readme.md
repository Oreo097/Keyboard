# Copy/Paste Keymap
![Picture](https://i.imgur.com/7LMZZrL.png)
