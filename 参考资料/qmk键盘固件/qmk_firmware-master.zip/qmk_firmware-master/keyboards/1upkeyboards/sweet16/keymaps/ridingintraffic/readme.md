# Ridingtraffic's examples
===
This keymap has many features:
3 layers
Momentary layer switching
16 pixel neopixel
Unicode Enabled
Tap dance enabled

The rgb also updates depending on what layer you are on, and then flips back when done.
