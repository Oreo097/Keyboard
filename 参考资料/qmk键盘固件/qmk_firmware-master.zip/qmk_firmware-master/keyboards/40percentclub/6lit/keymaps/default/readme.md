# The default split keymap for 6lit
