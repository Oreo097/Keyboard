# Sweet 16 Macropad

A 4x4 numpad/macro pad sold by 1up Keyboards.

* Keyboard Maintainer: skullydazed
* Hardware Supported: Sweet16 Keyboard PCB
* Hardware Availability: [1up Keyboards](https://1upkeyboards.com/)

Revisions:
* [v1](./v1/)- The original macropad, designed by Bishop Keyboards
* [v2/promicro](./v2/promicro)- The second macropad built with a Pro Micro, designed by Clueboard
* [v2/proton_c](./v2/proton_c)- The second macropad built with a Proton C, designed by Clueboard
