# 常见问题

* [一般问题](faq_general.md)
* [构建和编译QMK](faq_build.md)
* [QMK调试和故障排除](faq_debug.md)
* [布局问题](faq_keymap.md)
