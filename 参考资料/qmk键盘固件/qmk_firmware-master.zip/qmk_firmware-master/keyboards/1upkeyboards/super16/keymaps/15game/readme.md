# Trying to put a game that plays like the 15 puzzle on the super16
The 15/16 puzzle consists of a grid where one space is free, and adjacent spaces can be swapped with the free space 
* future planned features:
* fix the start at red
* have a cute animation play when the puzzle is solved
