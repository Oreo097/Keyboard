# 助けを得る

<!---
  original document: d598f01cb:docs/getting_started_getting_help.md
  git diff d598f01cb HEAD -- docs/getting_started_getting_help.md | cat
-->

QMK に関して助けを得るための多くのリソースがあります。

## リアルタイム チャット

メインの [Discord server](https://discord.gg/Uq7gcHh) で QMK の開発者とユーザを見つけることができます。サーバには、ファームウェア、Toolbox、ハードウェアおよび Configurator についてチャットするための特定のチャンネルがあります。

## OLKB Subreddit

公式の QMK フォーラムは [reddit.com](https://reddit.com) の [/r/olkb](https://reddit.com/r/olkb) です。

## Github Issues

[GitHub で issue](https://github.com/qmk/qmk_firmware/issues) を開くことができます。issue が長期的な議論あるいはデバッグを必要とする場合は、特に便利です。
