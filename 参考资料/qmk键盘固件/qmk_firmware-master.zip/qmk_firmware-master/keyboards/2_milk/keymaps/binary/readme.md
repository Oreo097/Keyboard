# Binary keymap 
0 and 1 that's it 
