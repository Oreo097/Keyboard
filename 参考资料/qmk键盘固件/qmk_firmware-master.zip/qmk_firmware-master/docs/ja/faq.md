# よくある質問

<!---
  original document: d598f01cb:docs/faq.md
  git diff d598f01cb HEAD -- docs/faq.md | cat
-->

* [一般](ja/faq_general.md)
* [QMK のビルドあるいはコンパイル](ja/faq_build.md)
* [QMK のデバッグとトラブルシューティング](ja/faq_debug.md)
* [キーマップ](ja/faq_keymap.md)
